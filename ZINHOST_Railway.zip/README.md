# ZINHOST — Railway deployable web hosting panel

A full-stack starter that turns the old static ZinHost UI into a real web application with:

- User registration/login + remember-me sessions
- User dashboard, bots, files and startup pages
- Upload `.py` and `.zip` projects
- Start/stop/restart Python processes
- Live console log viewer + stdin endpoint
- Auto-restart
- Per-user bot, RAM and disk quotas
- Admin panel with user management, quota editing, suspension/deletion, file listing/download, and platform bot stop controls
- SQLite persistence under `/data`
- Railway Docker deployment

## Railway

1. Push this folder to GitHub.
2. Create a Railway project from the repo.
3. Add a **persistent volume** mounted at `/data`.
4. Set environment variables as needed. The defaults are `loqi` / `loqi` for the admin, but **change the admin password before exposing the service publicly**.
5. Railway supplies `PORT`; the container listens on it.

Recommended variables:

```text
ADMIN_USERNAME=loqi
ADMIN_PASSWORD=CHANGE_ME
DATA_DIR=/data
MAX_TOTAL_BOTS=10
DEFAULT_MAX_BOTS=1
DEFAULT_RAM_MB=512
DEFAULT_DISK_MB=1536
```

## Important architecture/security note

This build intentionally runs uploaded Python in the same Railway container as the web API. That is suitable as a personal/trusted-user prototype, not as a hardened public multi-tenant hosting service. Arbitrary Python can access the container's filesystem/network and consume resources. For a public service, move execution into isolated worker containers/VMs with cgroups, seccomp/AppArmor, network policy, per-job storage, and a queue/orchestrator.

The UI is inspired by the feature set and clean dark client-area pattern you described, but it does not copy Raven Host's proprietary branding/assets/code.
